package com.example.acessoapp;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final String DEVICE_NAME = "ESP32-RFID";
    private static final UUID BT_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private CardView cardStatus;
    private ImageView statusIcon;
    private TextView statusText;
    private TextView textUid;
    private TextView textNome;
    private TextView textHora;
    private TextView textBluetoothRaw;

    private BluetoothSocket socket;
    private BufferedReader reader;
    private Thread bluetoothThread;

    // Handler para agendar reconexão
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Receiver para detectar quando o ESP32 desconecta
    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (d != null && DEVICE_NAME.equals(d.getName())) {
                    Log.i(TAG, "ESP32 desconectou!");
                    runOnUiThread(MainActivity.this::setStatusDisconnected);
                    scheduleReconnection();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        solicitarPermissoesBluetooth();
        inicializarViews();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Registrar receiver de desconexão
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        registerReceiver(bluetoothReceiver, filter);
        // Iniciar tentativa de conexão
        iniciarBluetooth();
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(bluetoothReceiver);
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeConnection();
    }

    private void solicitarPermissoesBluetooth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            }
        }
    }

    private void inicializarViews() {
        cardStatus = findViewById(R.id.cardStatus);
        statusIcon = findViewById(R.id.image_status);
        statusText = findViewById(R.id.text_status);
        textUid = findViewById(R.id.text_uid);
        textNome = findViewById(R.id.text_nome);
        textHora = findViewById(R.id.text_data);
        textBluetoothRaw = findViewById(R.id.text_bluetooth_raw);
    }

    private void iniciarBluetooth() {
        bluetoothThread = new Thread(() -> {
            try {
                BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        runOnUiThread(() -> Toast.makeText(this, "Permissão BLUETOOTH_CONNECT não concedida", Toast.LENGTH_LONG).show());
                        return;
                    }
                }

                if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
                    Log.e(TAG, "Bluetooth não disponível ou desativado");
                    runOnUiThread(() -> Toast.makeText(this, "Bluetooth desativado", Toast.LENGTH_LONG).show());
                    return;
                }

                // Fechar conexão anterior, se existir
                closeConnection();

                BluetoothDevice device = bluetoothAdapter.getBondedDevices()
                        .stream()
                        .filter(d -> d.getName().equals(DEVICE_NAME))
                        .findFirst()
                        .orElse(null);

                if (device == null) {
                    Log.e(TAG, "Dispositivo não pareado: " + DEVICE_NAME);
                    runOnUiThread(() -> Toast.makeText(this, "Dispositivo não pareado: " + DEVICE_NAME, Toast.LENGTH_LONG).show());
                    return;
                }

                // Tentar socket padrão
                try {
                    socket = device.createRfcommSocketToServiceRecord(BT_UUID);
                    socket.connect();
                } catch (Exception e) {
                    Log.e(TAG, "Erro socket padrão, tentando fallback", e);
                    // Fallback via reflexão
                    java.lang.reflect.Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                    socket = (BluetoothSocket) m.invoke(device, 1);
                    socket.connect();
                }

                runOnUiThread(() -> {
                    statusIcon.setImageResource(R.drawable.ic_bluetooth_connected);
                    statusText.setText("Conectado");
                    statusText.setTextColor(Color.BLUE);
                });

                reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null && !Thread.currentThread().isInterrupted()) {
                    String rawMsg = line;
                    Log.d(TAG, "Recebido: " + rawMsg);
                    runOnUiThread(() -> textBluetoothRaw.setText(rawMsg));
                    try {
                        JsonObject json = JsonParser.parseString(rawMsg).getAsJsonObject();
                        String uid = json.get("uid").getAsString();
                        String nome = json.get("nome").getAsString();
                        String status = json.get("status").getAsString();
                        String hora = json.get("hora").getAsString();
                        runOnUiThread(() -> exibirDadosUsuario(uid, nome, status, hora));
                    } catch (Exception e) {
                        Log.e(TAG, "Erro ao parsear JSON", e);
                        runOnUiThread(() -> Toast.makeText(this, "Erro ao ler dados Bluetooth", Toast.LENGTH_SHORT).show());
                    }
                }

            } catch (Exception e) {
                Log.e(TAG, "Falha ao conectar Bluetooth", e);
                runOnUiThread(this::setStatusDisconnected);
                scheduleReconnection();
            }
        });
        bluetoothThread.start();
    }

    // Define UI como desconectado
    private void setStatusDisconnected() {
        statusIcon.setImageResource(R.drawable.ic_bluetooth_disabled);
        statusText.setText("Desconectado");
        statusText.setTextColor(Color.GRAY);
    }

    // Agenda reconexão em 5s
    private void scheduleReconnection() {
        handler.postDelayed(this::iniciarBluetooth, 5000);
    }

    private void exibirDadosUsuario(String uid, String nome, String status, String hora) {
        textUid.setText(uid);
        textNome.setText(nome);
        textHora.setText(hora);
        if ("autorizado".equalsIgnoreCase(status)) {
            animarAcessoAutorizado();
        } else {
            animarAcessoNegado();
        }
    }

    private void animarAcessoAutorizado() {
        statusText.setText("AUTORIZADO");
        statusText.setTextColor(ContextCompat.getColor(this, R.color.success_color));
        statusIcon.setImageResource(R.drawable.ic_check_circle);
        statusIcon.setColorFilter(ContextCompat.getColor(this, R.color.success_color));
        AnimatorSet set = new AnimatorSet();
        set.playTogether(
                ObjectAnimator.ofFloat(cardStatus, "scaleX", 1f, 1.05f, 1f).setDuration(600),
                ObjectAnimator.ofFloat(cardStatus, "scaleY", 1f, 1.05f, 1f).setDuration(600),
                ObjectAnimator.ofFloat(statusIcon, "scaleX", 0.5f, 1.2f, 1f).setDuration(800),
                ObjectAnimator.ofFloat(statusIcon, "scaleY", 0.5f, 1.2f, 1f).setDuration(800),
                ObjectAnimator.ofFloat(statusText, "alpha", 0f, 1f).setDuration(500)
        );
        animarCorFundo(Color.parseColor("#E8F5E8"));
        set.start();
    }

    private void animarAcessoNegado() {
        statusText.setText("ACESSO NEGADO");
        statusText.setTextColor(ContextCompat.getColor(this, R.color.error_color));
        statusIcon.setImageResource(R.drawable.ic_error);
        statusIcon.setColorFilter(ContextCompat.getColor(this, R.color.error_color));
        AnimatorSet set = new AnimatorSet();
        set.playTogether(
                ObjectAnimator.ofFloat(cardStatus, "translationX", 0, -25, 25, -25, 25, 0).setDuration(600),
                ObjectAnimator.ofFloat(statusIcon, "scaleX", 1f, 1.3f, 1f).setDuration(400),
                ObjectAnimator.ofFloat(statusIcon, "scaleY", 1f, 1.3f, 1f).setDuration(400),
                ObjectAnimator.ofFloat(statusText, "alpha", 0f, 1f).setDuration(500)
        );
        animarCorFundo(Color.parseColor("#FFE8E8"));
        set.start();
    }

    private void animarCorFundo(int color) {
        int fromColor = ContextCompat.getColor(this, R.color.card_background);
        ValueAnimator anim = ValueAnimator.ofArgb(fromColor, color, fromColor);
        anim.setDuration(1000);
        anim.addUpdateListener(a -> cardStatus.setCardBackgroundColor((int) a.getAnimatedValue()));
        anim.start();
    }

    // Fecha reader e socket
    private void closeConnection() {
        try {
            if (reader != null) reader.close();
            if (socket != null && socket.isConnected()) socket.close();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao fechar conexão", e);
        }
        if (bluetoothThread != null && bluetoothThread.isAlive()) {
            bluetoothThread.interrupt();
        }
    }
}
